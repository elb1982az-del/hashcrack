> ⚠️ AUTHORIZED USE ONLY. Use only on hashes and captures you own or are
> explicitly authorized to test.

# hashcrack

Fast, easy hash cracking with a real Android app, a local engine, and a Python
CLI. Pick files, tap a button, and see results.

## What is here

- `app/` — Android controller app (`com.hashcrack.commander`)
- `engine/` — local JSON-lines engine on `127.0.0.1:8767`
- `hashcrack.py` + `hashcrack/` — Python CLI and modules
- `tests/` — unit tests
- `examples/` — sample hashes

bettercap-style controller idea, but for hashes: the APK is only the UI. The
engine and hashcat run in the Kali chroot.

## Android app

The app has three simple screens:

- **CRACK** — a simple 3-step screen:
  **STEP 1 - ADD HASHES** (tap **PASTE HASHES** to copy from clipboard —
  no typing; or type and press keyboard **Done**; tap **SEE MY HASHES** to
  open and read the hash file; tap **COPY** to copy it),
  **STEP 2 - ADD FILE** (optional picker, auto-sorted into the right folder),
  **STEP 3 - START CRACK**.
  Advanced choices are below under "MORE OPTIONS (optional)".
- **RESULTS** — cracked passwords and **CLEAR RESULTS**
- **FILES** — **ADD FILE** copies any file from the phone into the right folder
  automatically (hash-like lines → hashes, plain word lists → wordlists,
  `.rule` → rules, captures → app root); **REFRESH** updates the list;
  tap a filename to open and read its contents; tap **COPY** in the viewer to
  copy that file's text to the clipboard

The header shows engine status and a **START ENGINE** button.

Installed APK:

```text
/sdcard/Download/HashCrack-Commander.apk
MD5: b25d25739f3ddab628ee61cd461ff6e3
```

Start everything:

```sh
sh /sdcard/Download/HC_LAUNCH.sh
```

## Engine

The engine wraps the CLI and streams progress to the app.

```sh
cd engine
python3 -m py_compile hashcrack_engine.py
./start.sh
./stop.sh
./relaunch.sh
```

Socket: `127.0.0.1:8767`

Commands: `ping`, `status`, `files`, `read_file`, `save_hashes`, `import_file`,
`identify`, `crack`, `stop`, `results`, `clear`.
Events: `hello`, `status`, `files`, `log`, `result`, `cracked`.

Files live in `/sdcard/Download/hashcrack`:

```text
wordlists/rockyou.txt
wordlists/quick.txt
rules/best66.rule
rules/d3ad0ne.rule
rules/generated2.rule
rules/Incisive-leetspeak.rule
hashes/example_hashes.txt
hashes/my_hashes.txt
cracked.txt
```

## CLI

Still available for terminal use:

```sh
python3 hashcrack.py identify 5f4dcc3b5aa765d61d8327deb882cf99
python3 hashcrack.py crack 5f4dcc3b5aa765d61d8327deb882cf99 -w rockyou.txt
python3 hashcrack.py auto hashes.txt
python3 hashcrack.py crack capture.cap -w rockyou.txt
```

Features: auto-identify, wordlist/rule/mask/auto attacks, WPA `.cap` →
`hc22000`, hashcat-first speed, pure-Python fallback, sessions and result files.

## Tests

```sh
python3 -m unittest discover -s tests -v
```

## Build the app

```sh
cd app
./gradlew assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`
