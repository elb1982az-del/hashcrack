import hashlib
import tempfile
import unittest
from pathlib import Path

from hashcrack.backends import Attack, PythonBackend
from hashcrack.detect import Detection, detect_line
from hashcrack.target import Target, prepare_target


class DetectionTests(unittest.TestCase):
    def test_common_hashes(self):
        cases = [
            ("5f4dcc3b5aa765d61d8327deb882cf99", 0),
            ("5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8", 100),
            ("5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8", 1400),
            ("$2b$12$" + "a" * 53, 3200),
            ("$6$salt$" + "a" * 86, 1800),
        ]
        for value, expected_mode in cases:
            with self.subTest(value=value[:20]):
                self.assertEqual(detect_line(value).mode, expected_mode)

    def test_ntlm_hint(self):
        detection = detect_line("5f4dcc3b5aa765d61d8327deb882cf99", "ntlm")
        self.assertEqual(detection.mode, 1000)
        self.assertEqual(detection.name, "NTLM")


class PythonBackendTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.workdir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def _target(self, hashes, detection):
        target = Target("<test>", detection, hashes)
        return prepare_target(target, self.workdir)

    def test_wordlist_crack(self):
        password = "password"
        digest = hashlib.sha256(password.encode()).hexdigest()
        wordlist = self.workdir / "words.txt"
        wordlist.write_text("wrong\n" + password + "\n", encoding="utf-8")

        prepared = self._target([digest], Detection("SHA-256", 1400))
        backend = PythonBackend(self.workdir, "test")
        result = backend.run(prepared, Attack("wordlist", wordlist=wordlist),
                             Detection("SHA-256", 1400))
        self.assertTrue(result.ok)
        self.assertEqual(result.found, [password])

    def test_mask_crack(self):
        password = "abc"
        digest = hashlib.md5(password.encode()).hexdigest()
        prepared = self._target([digest], Detection("MD5", 0))
        backend = PythonBackend(self.workdir, "masktest")
        result = backend.run(prepared, Attack("mask", mask="?l?l?l"),
                             Detection("MD5", 0))
        self.assertTrue(result.ok)
        self.assertEqual(result.found, [password])


if __name__ == "__main__":
    unittest.main()
