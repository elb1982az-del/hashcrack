package com.hashcrack.commander

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.TextButton
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets

private const val ENGINE_HOST = "127.0.0.1"
private const val ENGINE_PORT = 8767

private val Bg = Color(0xFF0B120F)
private val CardColor = Color(0xFF15231D)
private val Green = Color(0xFF69F0AE)
private val TextColor = Color(0xFFE8F5EE)
private val Muted = Color(0xFF9CB3A8)
private val Red = Color(0xFFFF8080)

private class EngineClient(
    private val onStatus: (String) -> Unit,
    private val onEvent: (JSONObject) -> Unit,
) {
    private var socket: Socket? = null
    private var writer: BufferedWriter? = null
    private val sendLock = Any()
    private val pending = ArrayDeque<String>()
    @Volatile private var running = false

    suspend fun connect() = withContext(Dispatchers.IO) {
        if (running) return@withContext
        running = true
        while (running) {
            var current: Socket? = null
            try {
                onStatus("Connecting...")
                current = Socket()
                current.connect(InetSocketAddress(ENGINE_HOST, ENGINE_PORT), 2000)
                socket = current
                writer = BufferedWriter(
                    OutputStreamWriter(current.getOutputStream(), StandardCharsets.UTF_8)
                )
                onStatus("Online")
                synchronized(sendLock) {
                    while (pending.isNotEmpty()) {
                        writer?.write(pending.removeFirst())
                        writer?.newLine()
                    }
                    writer?.flush()
                }
                val reader = current.getInputStream().bufferedReader(StandardCharsets.UTF_8)
                while (running) {
                    val line = reader.readLine() ?: break
                    try {
                        onEvent(JSONObject(line))
                    } catch (_: Exception) {
                    }
                }
            } catch (_: Exception) {
            } finally {
                writer = null
                try { current?.close() } catch (_: Exception) {}
                if (socket === current) socket = null
            }
            if (running) {
                onStatus("Offline - retrying")
                delay(300)
            }
        }
    }

    fun send(cmd: String, extras: Map<String, Any?> = emptyMap()) {
        val json = JSONObject().put("cmd", cmd)
        extras.forEach { (key, value) ->
            if (value == null) json.put(key, JSONObject.NULL) else json.put(key, value)
        }
        val line = json.toString()
        synchronized(sendLock) {
            val w = writer
            if (w == null) {
                if (pending.size >= 30) pending.removeFirst()
                pending.addLast(line)
                onStatus("Queued: $cmd")
                try { socket?.close() } catch (_: Exception) {}
                return@synchronized
            }
            try {
                w.write(line)
                w.newLine()
                w.flush()
            } catch (_: Exception) {
                writer = null
                if (pending.size >= 30) pending.removeFirst()
                pending.addLast(line)
                onStatus("Queued after write error: $cmd")
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    fun close() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var client: EngineClient

    val status = mutableStateOf("Connecting...")
    val online = mutableStateOf(false)
    val running = mutableStateOf(false)
    val lastResult = mutableStateOf("Ready")
    val auto = mutableStateOf(true)

    val logs = mutableStateListOf<String>()
    val cracked = mutableStateListOf<String>()
    val wordlists = mutableStateListOf<String>()
    val rules = mutableStateListOf<String>()
    val hashFiles = mutableStateListOf<String>()
    val captures = mutableStateListOf<String>()

    val selectedWordlist = mutableStateOf("")
    val selectedRule = mutableStateOf("")
    val selectedHash = mutableStateOf("")
    val selectedCapture = mutableStateOf("")
    val selectedType = mutableStateOf("auto")
    val hashInput = mutableStateOf("")
    val mask = mutableStateOf("")

    val showFile = mutableStateOf(false)
    val fileViewerName = mutableStateOf("")
    val fileViewerText = mutableStateOf("")

    private lateinit var filePicker: ActivityResultLauncher<Array<String>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        filePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importUri(uri)
        }
        client = EngineClient(
            onStatus = { value ->
                runOnUiThread {
                    status.value = value
                    online.value = value == "Online"
                }
            },
            onEvent = { event -> runOnUiThread { handleEvent(event) } },
        )

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Green,
                    secondary = Green,
                    background = Bg,
                    surface = CardColor,
                    onPrimary = Bg,
                    onBackground = TextColor,
                    onSurface = TextColor,
                )
            ) {
                Root(this)
            }
        }
        lifecycleScope.launch { client.connect() }
    }

    override fun onDestroy() {
        client.close()
        super.onDestroy()
    }

    private fun handleEvent(event: JSONObject) {
        when (event.optString("event")) {
            "hello" -> {
                online.value = true
                status.value = "Online"
            }
            "status" -> {
                event.optJSONObject("data")?.let { running.value = it.optBoolean("running") }
            }
            "files" -> {
                event.optJSONObject("data")?.let { data ->
                    replaceList(wordlists, data.optJSONArray("wordlists"))
                    replaceList(rules, data.optJSONArray("rules"))
                    replaceList(hashFiles, data.optJSONArray("hashes"))
                    replaceList(captures, data.optJSONArray("captures"))
                    if (selectedWordlist.value.isBlank()) {
                        selectedWordlist.value = wordlists.firstOrNull { it.endsWith("quick.txt") }
                            ?: wordlists.firstOrNull().orEmpty()
                    }
                    if (selectedRule.value.isBlank()) {
                        selectedRule.value = rules.firstOrNull().orEmpty()
                    }
                    if (selectedHash.value.isBlank()) {
                        selectedHash.value = hashFiles.firstOrNull { it.endsWith("my_hashes.txt") }
                            ?: hashFiles.firstOrNull().orEmpty()
                    }
                }
            }
            "file_content" -> {
                event.optJSONObject("data")?.let { data ->
                    fileViewerName.value = data.optString("name")
                    fileViewerText.value = data.optString("text")
                    showFile.value = true
                }
            }
            "log" -> {
                val line = event.optJSONObject("data")?.optString("line").orEmpty()
                if (line.isNotBlank()) {
                    logs.add(line)
                    while (logs.size > 80) logs.removeAt(0)
                }
            }
            "result" -> {
                val cmd = event.optString("cmd")
                val message = event.optString("message")
                lastResult.value = "$cmd: $message"
            }
            "cracked" -> {
                val array = event.optJSONObject("data")?.optJSONArray("passwords")
                cracked.clear()
                if (array != null) {
                    for (index in 0 until array.length()) {
                        cracked.add(array.optString(index))
                    }
                }
            }
        }
    }

    private fun replaceList(target: MutableList<String>, array: org.json.JSONArray?) {
        target.clear()
        if (array == null) return
        for (index in 0 until array.length()) {
            val value = array.optString(index)
            if (value.isNotBlank()) target.add(value)
        }
    }

    private fun selectedTarget(): String {
        val capture = selectedCapture.value.trim()
        if (capture.isNotBlank()) return capture
        val pasted = hashInput.value.trim()
        if (pasted.isNotBlank()) return pasted
        return selectedHash.value.trim()
    }

    fun startCrack() {
        val target = selectedTarget()
        if (target.isBlank()) {
            lastResult.value = "Choose a hash, hash list, or capture"
            return
        }
        val extras = mutableMapOf<String, Any?>("target" to target)
        if (selectedWordlist.value.isNotBlank()) extras["wordlist"] = selectedWordlist.value
        if (selectedRule.value.isNotBlank()) extras["rule"] = selectedRule.value
        if (mask.value.isNotBlank()) extras["mask"] = mask.value
        if (selectedType.value != "auto") extras["type"] = selectedType.value
        extras["auto"] = auto.value
        client.send("crack", extras)
        lastResult.value = "Starting crack..."
    }

    fun identify() {
        val target = selectedTarget()
        if (target.isBlank()) {
            lastResult.value = "Choose a target first"
            return
        }
        client.send("identify", mapOf("target" to target))
        lastResult.value = "Identifying..."
    }

    fun stop() {
        client.send("stop")
        lastResult.value = "Stop requested"
    }

    fun refreshFiles() {
        client.send("files")
        lastResult.value = "Refreshing files..."
    }

    fun addHashes() {
        val text = hashInput.value.trim()
        if (text.isBlank()) {
            lastResult.value = "Paste hashes first"
            return
        }
        client.send("save_hashes", mapOf("hashes" to text, "name" to "my_hashes.txt"))
        selectedHash.value = ""
        lastResult.value = "Saving hashes..."
    }

    fun pasteHashes() {
        try {
            val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = manager.primaryClip?.getItemAt(0)?.text?.toString()?.trim().orEmpty()
            if (text.isBlank()) {
                lastResult.value = "Clipboard empty - copy the hash first"
                return
            }
            hashInput.value = text
            client.send("save_hashes", mapOf("hashes" to text, "name" to "my_hashes.txt"))
            selectedHash.value = ""
            lastResult.value = "Pasted ${text.lines().size} line(s) - saving now"
        } catch (exc: Exception) {
            lastResult.value = "Paste failed: ${exc.message}"
        }
    }

    fun viewFile(path: String) {
        if (path.isBlank()) {
            lastResult.value = "Choose a file first"
            return
        }
        client.send("read_file", mapOf("path" to path))
        lastResult.value = "Opening ${path.substringAfterLast('/')}"
    }

    fun viewHashes() {
        val path = selectedHash.value.ifBlank { hashFiles.firstOrNull().orEmpty() }
        viewFile(path)
    }

    fun copyFileText() {
        try {
            val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            manager.setPrimaryClip(
                ClipData.newPlainText("hashcrack", fileViewerText.value)
            )
            lastResult.value = "Copied ${fileViewerName.value} to clipboard"
        } catch (exc: Exception) {
            lastResult.value = "Copy failed: ${exc.message}"
        }
    }

    fun pickFile() {
        filePicker.launch(arrayOf("*/*"))
    }

    private fun importUri(uri: Uri) {
        val pickedName = (uri.lastPathSegment?.substringAfterLast('/') ?: "")
            .takeIf { it.isNotBlank() } ?: "imported.txt"
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("cannot open file")
                if (bytes.size > 200 * 1024 * 1024) {
                    throw IllegalStateException("file too large (limit 200 MB)")
                }
                val lower = pickedName.lowercase()
                val sampleLength = minOf(bytes.size, 65536)
                val sample = String(bytes, 0, sampleLength, StandardCharsets.UTF_8)
                val lines = sample.lineSequence()
                    .map { it.trim() }
                    .filter { it.isNotEmpty() && !it.startsWith("#") }
                    .take(50)
                    .toList()
                val hashPattern = Regex(
                    "^([0-9a-fA-F]{32}|[0-9a-fA-F]{40}|[0-9a-fA-F]{64}|[0-9a-fA-F]{128})$"
                )
                val hashLike = lines.count { hashPattern.matches(it) || it.contains('$') }
                val kind = when {
                    lower.endsWith(".rule") -> "rules"
                    lower.endsWith(".cap") || lower.endsWith(".pcap") ||
                        lower.endsWith(".pcapng") || lower.endsWith(".hc22000") ||
                        lower.endsWith(".hccapx") -> "captures"
                    lower.endsWith(".hash") -> "hashes"
                    lower.contains("wordlist") || lower.contains("rockyou") ||
                        lower.endsWith(".dic") || lower.endsWith(".lst") -> "wordlists"
                    lines.isNotEmpty() && hashLike * 2 >= lines.size -> "hashes"
                    else -> "wordlists"
                }
                client.send(
                    "import_file",
                    mapOf(
                        "name" to pickedName,
                        "kind" to kind,
                        "data" to Base64.encodeToString(bytes, Base64.NO_WRAP),
                    ),
                )
                withContext(Dispatchers.Main) {
                    lastResult.value = "Importing $pickedName..."
                }
            } catch (exc: Exception) {
                withContext(Dispatchers.Main) {
                    lastResult.value = "Import failed: ${exc.message}"
                }
            }
        }
    }

    fun clearResults() {
        client.send("clear")
        lastResult.value = "Results cleared"
    }

    fun startEngine() {
        lastResult.value = "Starting engine..."
        Thread {
            try {
                Runtime.getRuntime().exec(arrayOf("su", "-c", "sh /sdcard/Download/HC_LAUNCH.sh"))
            } catch (_: Exception) {
                try {
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "sh /sdcard/Download/HC_LAUNCH.sh"))
                } catch (_: Exception) {
                }
            }
        }.start()
    }
}

@Composable
fun Root(activity: MainActivity) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Header(activity)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TabButton("CRACK", tab == 0) { tab = 0 }
            TabButton("RESULTS", tab == 1) { tab = 1 }
            TabButton("FILES", tab == 2) { tab = 2 }
        }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> CrackTab(activity)
            1 -> ResultsTab(activity)
            2 -> FilesTab(activity)
        }
        if (activity.showFile.value) FileViewerDialog(activity)
    }
}

@Composable
fun Header(activity: MainActivity) {
    Card(
        Modifier.fillMaxWidth().padding(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardColor),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("HASHCRACK", color = Green, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Commander", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(
                    text = if (activity.online.value) "● ONLINE" else "● ${activity.status.value}",
                    color = if (activity.online.value) Green else Red,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Button(
                    onClick = { activity.startEngine() },
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg),
                ) { Text("START ENGINE") }
            }
            Spacer(Modifier.height(8.dp))
            Text("Last: ${activity.lastResult.value}", color = TextColor, fontSize = 13.sp)
            if (activity.running.value) {
                Text("CRACKING IN PROGRESS", color = Green, fontSize = 13.sp,
                     fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RowScope.TabButton(label: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) Green else CardColor,
            contentColor = if (selected) Bg else TextColor,
        ),
        shape = RoundedCornerShape(12.dp),
    ) { Text(label) }
}

@Composable
fun CrackTab(activity: MainActivity) {
    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            val focusRequester = remember { FocusRequester() }
            LaunchedEffect(Unit) { focusRequester.requestFocus() }
            CardSection("STEP 1 - ADD HASHES") {
                Text(
                    "Copy your hash anywhere, then tap PASTE. No typing needed.",
                    color = TextColor,
                    fontSize = 14.sp,
                )
                Button(
                    onClick = { activity.pasteHashes() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg),
                    shape = RoundedCornerShape(14.dp),
                ) { Text("PASTE HASHES (no typing)", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                OutlinedTextField(
                    value = activity.hashInput.value,
                    onValueChange = { activity.hashInput.value = it },
                    label = { Text("Or type/paste here") },
                    modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                    minLines = 3,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { activity.addHashes() }),
                )
                Button(
                    onClick = { activity.addHashes() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg),
                    shape = RoundedCornerShape(14.dp),
                ) { Text("ADD HASHES", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                Button(
                    onClick = { activity.viewHashes() },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CardColor,
                        contentColor = TextColor,
                    ),
                    shape = RoundedCornerShape(12.dp),
                ) { Text("SEE MY HASHES", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                Text(
                    "Tap SEE MY HASHES to open and read the file.",
                    color = Muted,
                    fontSize = 12.sp,
                )
            }
        }
        item {
            CardSection("STEP 2 - ADD FILE (optional)") {
                Text(
                    "Pick any file. The app puts it in the right folder automatically.",
                    color = TextColor,
                    fontSize = 14.sp,
                )
                Button(
                    onClick = { activity.pickFile() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg),
                    shape = RoundedCornerShape(14.dp),
                ) { Text("ADD FILE", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            }
        }
        item {
            Button(
                onClick = { activity.startCrack() },
                modifier = Modifier.fillMaxWidth().height(64.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg),
                shape = RoundedCornerShape(16.dp),
            ) { Text("STEP 3 - START CRACK", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        }
        item {
            CardSection("CURRENT CHOICES") {
                Text(
                    "Hashes: ${activity.selectedHash.value.substringAfterLast('/').ifBlank { "none" }}",
                    color = TextColor, fontSize = 13.sp,
                )
                Text(
                    "Wordlist: ${activity.selectedWordlist.value.substringAfterLast('/').ifBlank { "none" }}",
                    color = TextColor, fontSize = 13.sp,
                )
                Text(
                    "Rule: ${activity.selectedRule.value.substringAfterLast('/').ifBlank { "none" }}",
                    color = TextColor, fontSize = 13.sp,
                )
                Picker("Hash list", listOf("") + activity.hashFiles, activity.selectedHash.value) {
                    activity.selectedHash.value = it
                }
                Picker("Capture file", listOf("") + activity.captures, activity.selectedCapture.value) {
                    activity.selectedCapture.value = it
                }
            }
        }
        item {
            CardSection("MORE OPTIONS (optional)") {
                Picker("Wordlist", activity.wordlists, activity.selectedWordlist.value) {
                    activity.selectedWordlist.value = it
                }
                Picker("Rule file", listOf("") + activity.rules, activity.selectedRule.value) {
                    activity.selectedRule.value = it
                }
                Picker(
                    "Hash type",
                    listOf("auto", "md5", "sha1", "sha256", "ntlm", "wpa"),
                    activity.selectedType.value,
                ) { activity.selectedType.value = it }
                OutlinedTextField(
                    value = activity.mask.value,
                    onValueChange = { activity.mask.value = it },
                    label = { Text("Mask, e.g. ?l?l?l?d?d") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Auto chain: wordlist → rules → mask", color = TextColor,
                         modifier = Modifier.weight(1f))
                    Switch(checked = activity.auto.value,
                           onCheckedChange = { activity.auto.value = it })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { activity.identify() }, modifier = Modifier.weight(1f)) {
                        Text("IDENTIFY")
                    }
                    Button(onClick = { activity.stop() }, modifier = Modifier.weight(1f),
                           colors = ButtonDefaults.buttonColors(containerColor = Red,
                                                                contentColor = Color.White)) {
                        Text("STOP")
                    }
                }
            }
        }
        item {
            CardSection("STATUS") {
                activity.logs.takeLast(10).forEach { line ->
                    Text(line, color = Muted, fontSize = 12.sp)
                }
                if (activity.logs.isEmpty()) Text("No output yet.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun ResultsTab(activity: MainActivity) {
    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            CardSection("CRACKED PASSWORDS") {
                Text("${activity.cracked.size} result(s)", color = Green, fontSize = 18.sp,
                     fontWeight = FontWeight.Bold)
                Button(onClick = { activity.clearResults() },
                       colors = ButtonDefaults.buttonColors(containerColor = Red,
                                                            contentColor = Color.White)) {
                    Text("CLEAR RESULTS")
                }
            }
        }
        items(activity.cracked) { password ->
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardColor),
                shape = RoundedCornerShape(12.dp),
            ) {
                Text(password, color = TextColor, modifier = Modifier.padding(14.dp))
            }
        }
    }
}

@Composable
fun FilesTab(activity: MainActivity) {
    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { activity.pickFile() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Green,
                        contentColor = Bg,
                    ),
                ) { Text("ADD FILE") }
                Button(
                    onClick = { activity.refreshFiles() },
                    modifier = Modifier.weight(1f),
                ) { Text("REFRESH") }
            }
        }
        item {
            Text(
                "ADD FILE copies a file from your phone into this app's folders. " +
                    "Wordlists, rules, hashes and captures are found automatically.",
                color = Muted,
                fontSize = 12.sp,
            )
        }
        item { FileSection("Wordlists", activity.wordlists, activity) }
        item { FileSection("Rules", activity.rules, activity) }
        item { FileSection("Hash lists", activity.hashFiles, activity) }
        item { FileSection("Captures", activity.captures, activity) }
    }
}

@Composable
fun FileViewerDialog(activity: MainActivity) {
    AlertDialog(
        onDismissRequest = { activity.showFile.value = false },
        title = { Text(activity.fileViewerName.value, color = Green) },
        text = {
            SelectionContainer {
                Text(
                    text = activity.fileViewerText.value.ifBlank { "(empty file)" },
                    color = TextColor,
                    fontSize = 13.sp,
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                )
            }
        },
        dismissButton = {
            TextButton(onClick = { activity.copyFileText() }) {
                Text("COPY", color = Green)
            }
        },
        confirmButton = {
            TextButton(onClick = { activity.showFile.value = false }) {
                Text("CLOSE", color = Green)
            }
        },
    )
}

@Composable
fun FileSection(title: String, values: List<String>, activity: MainActivity) {
    CardSection(title) {
        if (values.isEmpty()) Text("None found", color = Muted, fontSize = 13.sp)
        values.forEach { value ->
            Text(
                text = value.substringAfterLast('/'),
                color = TextColor,
                fontSize = 13.sp,
                modifier = Modifier.clickable { activity.viewFile(value) },
            )
        }
        if (values.isNotEmpty()) {
            Text("Tap a file to see what is inside.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun CardSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardColor),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Green, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
fun Picker(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(label, color = Muted, fontSize = 12.sp)
        Button(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = CardColor,
                contentColor = TextColor,
            ),
            shape = RoundedCornerShape(10.dp),
        ) { Text(selected.ifBlank { "none" }) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.ifBlank { "none" }) },
                    onClick = { onSelect(option); expanded = false },
                )
            }
        }
    }
}
