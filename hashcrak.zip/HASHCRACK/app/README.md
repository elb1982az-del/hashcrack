> ⚠️ AUTHORIZED USE ONLY. Use only on hashes and captures you own or are
> explicitly authorized to test.

# HashCrack Commander (Android app)

Simple Android controller for the local HashCrack engine. Pick files from
Download, tap a big button, and see cracked passwords. No commands to type.

## Screens

- **CRACK** — a simple 3-step screen:
  **STEP 1 - ADD HASHES** (tap **PASTE HASHES** to copy from clipboard —
  no typing; or type and press keyboard **Done**; tap **SEE MY HASHES** to
  open and read the hash file; tap **COPY** to copy it),
  **STEP 2 - ADD FILE** (optional picker, auto-sorted into the right folder),
  **STEP 3 - START CRACK**.
  "MORE OPTIONS (optional)" holds wordlist, rule, hash type, mask, IDENTIFY, STOP.
- **RESULTS** — cracked password list with **CLEAR RESULTS**
- **FILES** — **ADD FILE** copies any file from the phone into the right folder
  automatically (hash-like lines → hashes, plain word lists → wordlists,
  `.rule` → rules, captures → app root); **REFRESH** updates the list;
  tap a filename to open and read its contents; tap **COPY** in the viewer to
  copy that file's text to the clipboard

The header shows engine status and a **START ENGINE** button.

## Build

Requirements: JDK 17+, Android SDK platform 35.

```sh
./gradlew assembleDebug
```

Fresh debug build, V1 + V2 + V3 signing, `minSdk 24`, `targetSdk 35`.

## Installed APK

```text
/sdcard/Download/HashCrack-Commander.apk
MD5: b25d25739f3ddab628ee61cd461ff6e3
Package: com.hashcrack.commander
```

## Engine

The app connects to `127.0.0.1:8767`. Start or restart everything with:

```sh
sh /sdcard/Download/HC_LAUNCH.sh
```
