#!/usr/bin/env python3
"""hashcrack CLI entry point."""

from hashcrack.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
