"""Hash identification and hashcat mode mapping."""

from __future__ import annotations

import re
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Optional

WPA_EXTENSIONS = {".cap", ".pcap", ".pcapng", ".hccapx", ".hccap", ".hc22000"}

_HEX = re.compile(r"^[0-9a-fA-F]+$")
_BCRYPT = re.compile(r"^\$2[aby]\$\d\d\$[./A-Za-z0-9]{53}$")
_MD5CRYPT = re.compile(r"^\$1\$[^$]{1,8}\$[./A-Za-z0-9]{22}$")
_SHA256CRYPT = re.compile(r"^\$5\$[^$]{1,16}(\$[^$]+)?\$[./A-Za-z0-9]{43}$")
_SHA512CRYPT = re.compile(r"^\$6\$[^$]{1,16}(\$[^$]+)?\$[./A-Za-z0-9]{86}$")


@dataclass(frozen=True)
class Detection:
    name: str
    mode: Optional[int]
    confidence: str = "high"
    note: str = ""


HINTS = {
    "md5": Detection("MD5", 0),
    "sha1": Detection("SHA-1", 100),
    "sha256": Detection("SHA-256", 1400),
    "sha512": Detection("SHA-512", 1700),
    "ntlm": Detection("NTLM", 1000),
    "lm": Detection("LM", 3000),
    "netntlmv2": Detection("NetNTLMv2", 5600),
    "bcrypt": Detection("bcrypt", 3200),
    "md5crypt": Detection("md5crypt", 500),
    "sha256crypt": Detection("sha256crypt", 7400),
    "sha512crypt": Detection("sha512crypt", 1800),
    "wpa": Detection("WPA/WPA2", 22000),
    "pmkid": Detection("WPA-PMKID", 22000),
}


def normalize_hint(hint: Optional[str]) -> Optional[str]:
    if not hint:
        return None
    value = hint.strip().lower().replace("-", "").replace("_", "")
    aliases = {
        "sha1": "sha1",
        "sha256": "sha256",
        "sha512": "sha512",
        "md5": "md5",
        "ntlm": "ntlm",
        "lm": "lm",
        "netntlmv2": "netntlmv2",
        "netntlm": "netntlmv2",
        "bcrypt": "bcrypt",
        "md5crypt": "md5crypt",
        "sha256crypt": "sha256crypt",
        "sha512crypt": "sha512crypt",
        "wpa": "wpa",
        "pmkid": "pmkid",
    }
    return aliases.get(value)


def detect_line(raw: str, hint: Optional[str] = None) -> Detection:
    """Detect one hash line. Never raises on odd input."""
    value = raw.strip()

    normalized = normalize_hint(hint)
    if normalized and normalized in HINTS:
        return HINTS[normalized]

    if not value or value.startswith("#"):
        return Detection("empty", None, "low", "Skipped blank or comment line.")

    if value.startswith("WPA*02*"):
        return Detection("WPA2 hc22000 (PMKID/EAPOL)", 22000, "high")
    if value.startswith("WPA*01*"):
        return Detection("WPA PMKID hc22000", 22000, "high")
    if value.startswith("*") and len(value.split("*")) >= 4:
        return Detection("WPA PMKID (legacy)", 16800, "medium",
                         "Convert to hc22000 with hcxpcapngtool for best results.")

    if _BCRYPT.match(value):
        return Detection("bcrypt", 3200, "high")
    if _MD5CRYPT.match(value):
        return Detection("md5crypt", 500, "high")
    if _SHA256CRYPT.match(value):
        return Detection("sha256crypt", 7400, "high")
    if _SHA512CRYPT.match(value):
        return Detection("sha512crypt", 1800, "high")
    if value.startswith("$y$"):
        return Detection("yescrypt", None, "medium",
                         "Use john for yescrypt; hashcat mode is version-dependent.")
    if value.startswith("$argon2"):
        return Detection("Argon2", None, "medium",
                         "Use john for Argon2; hashcat mode is version-dependent.")

    parts = value.split(":")
    if len(parts) >= 5 and _HEX.match(parts[-1]) and len(parts[-1]) >= 32:
        return Detection("NetNTLMv2", 5600, "medium",
                         "Colon-separated response detected.")

    if not _HEX.match(value):
        return Detection("unknown", None, "low", "No known hash pattern matched.")

    size = len(value)
    if size == 32:
        return Detection("MD5 / NTLM / LM (32 hex)", 0, "medium",
                         "Default is MD5. Use --type ntlm or --type lm if known.")
    if size == 40:
        return Detection("SHA-1", 100, "high")
    if size == 64:
        return Detection("SHA-256", 1400, "high")
    if size == 128:
        return Detection("SHA-512", 1700, "high")

    return Detection(f"unknown hex ({size})", None, "low",
                     "Try --mode with an explicit hashcat mode.")


def detect_file(path: Path, hint: Optional[str] = None) -> Detection:
    """Detect a hash file or WPA capture file."""
    suffix = path.suffix.lower()
    if suffix in WPA_EXTENSIONS:
        if suffix == ".hccapx":
            return Detection("WPA hccapx capture", 2500, "high")
        if suffix == ".hc22000":
            return Detection("WPA hc22000 capture", 22000, "high")
        return Detection("WPA capture file", 22000, "medium",
                         "Will convert to hc22000 before cracking.")

    found: list[Detection] = []
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            found.append(detect_line(line, hint))
            if len(found) >= 200:
                break

    if not found:
        return Detection("empty hash file", None, "low", "No hash lines found.")

    best = found[0]
    for candidate in found[1:]:
        if candidate.mode == best.mode:
            continue
        return replace(
            best,
            note=(best.note + " " if best.note else "") +
                 "Mixed hash types detected; first type was used. Split the file for best results.",
            confidence="low",
        )
    return best
