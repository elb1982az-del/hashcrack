"""Hashcat and pure-Python cracking backends."""

from __future__ import annotations

import hashlib
import itertools
import re
import string
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator, Optional

from .detect import Detection
from .target import PreparedTarget
from .tools import ToolError, which

ATTACK_CODES = {"wordlist": 0, "rule": 0, "mask": 3}
CHARSETS = {
    "l": string.ascii_lowercase,
    "u": string.ascii_uppercase,
    "d": string.digits,
    "s": string.punctuation,
    "a": string.ascii_letters + string.digits + string.punctuation,
}


@dataclass
class Attack:
    kind: str
    wordlist: Optional[Path] = None
    rule: Optional[Path] = None
    mask: Optional[str] = None
    label: str = ""

    def describe(self) -> str:
        if self.label:
            return self.label
        if self.kind == "mask":
            return f"mask {self.mask}"
        if self.rule:
            return f"wordlist + rules ({self.rule.name})"
        return f"wordlist ({self.wordlist.name if self.wordlist else 'default'})"


@dataclass
class Result:
    ok: bool
    found: list[str]
    message: str = ""
    command: Optional[list[str]] = None


def session_paths(workdir: Path, session: str) -> tuple[Path, Path]:
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", session)
    return workdir / f"{safe}.pot", workdir / f"{safe}.out"


class HashcatBackend:
    name = "hashcat"

    def __init__(self, workdir: Path, session: str, quiet: bool = False):
        self.workdir = workdir
        self.session = session
        self.quiet = quiet
        self.potfile, self.outfile = session_paths(workdir, session)

    def available(self) -> bool:
        return which("hashcat") is not None

    def _command(self, prepared: PreparedTarget, attack: Attack, resume: bool) -> list[str]:
        hashcat = which("hashcat")
        if not hashcat:
            raise ToolError("hashcat not found on PATH")

        common = [
            hashcat,
            "--potfile-path", str(self.potfile),
            "--session", self.session,
            "-o", str(self.outfile),
            "--outfile-format", "2",
        ]
        if resume:
            return common + ["--restore"]

        cmd = common + [
            "-m", str(prepared.mode),
            "-a", str(ATTACK_CODES[attack.kind]),
        ]
        if not self.quiet:
            cmd += ["--status", "--status-timer", "1"]

        cmd.append(str(prepared.hashfile))
        if attack.kind == "mask":
            cmd.append(attack.mask or "")
        else:
            if attack.wordlist:
                cmd.append(str(attack.wordlist))
            if attack.rule:
                cmd += ["-r", str(attack.rule)]
        return cmd

    def run(
        self,
        prepared: PreparedTarget,
        attack: Attack,
        resume: bool = False,
    ) -> Result:
        self.outfile.unlink(missing_ok=True)
        try:
            cmd = self._command(prepared, attack, resume)
        except ToolError as exc:
            return Result(False, [], str(exc))

        try:
            proc = subprocess.run(cmd, check=False)
        except KeyboardInterrupt:
            return Result(False, [], "interrupted", cmd)
        except OSError as exc:
            return Result(False, [], f"hashcat failed to start: {exc}", cmd)

        found: list[str] = []
        if self.outfile.is_file():
            found = [
                line.rstrip("\r\n")
                for line in self.outfile.read_text(encoding="utf-8", errors="replace").splitlines()
                if line.strip()
            ]

        if found:
            return Result(True, found, "", cmd)
        if proc.returncode == 130:
            return Result(False, [], "interrupted", cmd)
        if proc.returncode == 1:
            return Result(False, [], "no password found (exhausted)", cmd)
        return Result(False, [], f"hashcat exited with code {proc.returncode}", cmd)


def _algorithm(detection: Detection) -> Optional[str]:
    name = detection.name.lower()
    if "bcrypt" in name or "crypt" in name and "md5 /" not in name:
        return None
    if "wpa" in name or "netntlm" in name:
        return None
    if "md5" in name:
        return "md5"
    if "sha-1" in name or "sha1" in name:
        return "sha1"
    if "sha-256" in name or "sha256" in name:
        return "sha256"
    if "sha-512" in name or "sha512" in name:
        return "sha512"
    if "ntlm" in name:
        try:
            hashlib.new("md4", b"test")
            return "md4"
        except ValueError:
            return None
    return None


def _iter_words(path: Path) -> Iterator[str]:
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            word = line.rstrip("\r\n")
            if word:
                yield word


def _rule_variants(word: str, rule: Optional[Path]) -> Iterator[str]:
    yield word
    if rule is None:
        return
    variants = {
        word.lower(),
        word.upper(),
        word.capitalize(),
        word + "1",
        word + "123",
        word + "!",
        word + "2024",
    }
    for variant in variants:
        if variant != word:
            yield variant


def _mask_positions(mask: str) -> list[str]:
    positions: list[str] = []
    index = 0
    while index < len(mask):
        if mask[index] != "?":
            positions.append(mask[index])
            index += 1
            continue
        if index + 1 >= len(mask):
            raise ToolError("mask ends with a lone '?'")
        code = mask[index + 1].lower()
        if code not in CHARSETS:
            raise ToolError(f"unknown mask token ?{code}")
        positions.append(CHARSETS[code])
        index += 2
    if not positions:
        raise ToolError("empty mask")
    return positions


def _iter_mask(mask: str) -> Iterator[str]:
    for parts in itertools.product(*_mask_positions(mask)):
        yield "".join(parts)


class PythonBackend:
    """Small fallback for unsalted fast hashes. Much slower than hashcat."""

    name = "python"

    def __init__(self, workdir: Path, session: str, quiet: bool = False):
        self.workdir = workdir
        self.session = session
        self.quiet = quiet
        self.potfile, self.outfile = session_paths(workdir, session)

    def available(self) -> bool:
        return True

    def _candidates(self, attack: Attack) -> Iterable[str]:
        if attack.kind == "mask":
            yield from _iter_mask(attack.mask or "")
            return
        if attack.wordlist is None:
            raise ToolError("python backend needs a wordlist for this attack")
        for word in _iter_words(attack.wordlist):
            for variant in _rule_variants(word, attack.rule):
                yield variant

    def run(
        self,
        prepared: PreparedTarget,
        attack: Attack,
        detection: Detection,
        resume: bool = False,
    ) -> Result:
        algorithm = _algorithm(detection)
        if algorithm is None:
            return Result(
                False,
                [],
                "pure-Python fallback supports MD5, SHA-1, SHA-256, SHA-512 and "
                "NTLM only. Use hashcat for this hash type.",
            )

        targets = {
            line.strip().lower()
            for line in prepared.hashfile.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines()
            if line.strip()
        }
        if not targets:
            return Result(False, [], "no hashes to crack")

        found: list[str] = []
        try:
            for candidate in self._candidates(attack):
                digest = hashlib.new(
                    algorithm, candidate.encode("utf-8", errors="ignore")
                ).hexdigest()
                if digest in targets:
                    found.append(candidate)
                    targets.discard(digest)
                    if not targets:
                        break
        except KeyboardInterrupt:
            return Result(False, found, "interrupted")
        except ToolError as exc:
            return Result(False, found, str(exc))

        self.outfile.unlink(missing_ok=True)
        if found:
            self.outfile.write_text("\n".join(found) + "\n", encoding="utf-8")
            self.potfile.write_text("\n".join(found) + "\n", encoding="utf-8")
            return Result(True, found, "")
        return Result(False, [], "no password found in supplied candidates")
