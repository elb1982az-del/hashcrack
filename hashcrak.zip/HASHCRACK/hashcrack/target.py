"""Target loading and preparation."""

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Optional

from .detect import WPA_EXTENSIONS, detect_file, detect_line
from .tools import ToolError
from .wpa import convert_capture


@dataclass
class Target:
    source: str
    detection: object
    hashes: list[str]
    wpa_file: Optional[Path] = None

    @property
    def count(self) -> int:
        return len(self.hashes)


@dataclass
class PreparedTarget:
    hashfile: Path
    mode: int
    label: str
    total: int


def load_target(value: str, hint: Optional[str] = None) -> Target:
    """Load a hash string or hash/capture file."""
    path = Path(value).expanduser()

    if path.is_file():
        detection = detect_file(path, hint)
        if path.suffix.lower() in WPA_EXTENSIONS:
            return Target(str(path), detection, [], path)

        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            raise ToolError(f"cannot read {path}: {exc}")

        hashes = [
            line.strip()
            for line in text.splitlines()
            if line.strip() and not line.strip().startswith("#")
        ]
        if not hashes:
            raise ToolError(f"no hash lines found in {path}")
        return Target(str(path), detection, hashes)

    text = value.strip()
    if not text:
        raise ToolError("empty target")

    hashes = [
        line.strip()
        for line in text.splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]
    detection = detect_line(hashes[0], hint)
    return Target("<inline>", detection, hashes)


def prepare_target(
    target: Target,
    workdir: Path,
    mode_override: Optional[int] = None,
) -> PreparedTarget:
    """Write a hashcat-ready hash file and return its mode."""
    workdir.mkdir(parents=True, exist_ok=True)

    mode = mode_override if mode_override is not None else target.detection.mode
    if mode is None:
        raise ToolError(
            "could not identify the hash type. "
            "Pass --type md5|sha1|sha256|ntlm|wpa or --mode <hashcat-mode>."
        )

    if target.wpa_file is not None:
        hashfile, detected_mode = convert_capture(target.wpa_file, workdir)
        if mode_override is None:
            mode = detected_mode
        return PreparedTarget(hashfile, mode, target.wpa_file.name, 1)

    hashfile = workdir / "target.hash"
    hashfile.write_text("\n".join(target.hashes) + "\n", encoding="utf-8")
    return PreparedTarget(hashfile, mode, target.source, target.count)
