"""Small terminal UI helpers. No external dependencies."""

from __future__ import annotations

import os
import sys
from typing import Optional

_COLORS = {
    "reset": "\033[0m",
    "bold": "\033[1m",
    "dim": "\033[2m",
    "red": "\033[31m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "blue": "\033[34m",
    "cyan": "\033[36m",
}


def colors_enabled() -> bool:
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def paint(text: str, color: str, bold: bool = False) -> str:
    if not colors_enabled():
        return text
    prefix = _COLORS.get(color, "")
    if bold:
        prefix += _COLORS["bold"]
    return f"{prefix}{text}{_COLORS['reset']}"


def info(message: str) -> None:
    print(paint(message, "cyan"))


def ok(message: str) -> None:
    print(paint(f"[+] {message}", "green", bold=True))


def warn(message: str) -> None:
    print(paint(f"[!] {message}", "yellow"))


def error(message: str) -> None:
    print(paint(f"[-] {message}", "red", bold=True))


def header(message: str) -> None:
    print(paint(f"\n== {message} ==", "blue", bold=True))


def detail(message: str) -> None:
    print(paint(f"    {message}", "dim"))


def section(title: str, value: Optional[str] = None) -> None:
    if value is None:
        print(paint(f"{title}:", "bold") if colors_enabled() else f"{title}:")
    else:
        print(f"{title}: {value}")
