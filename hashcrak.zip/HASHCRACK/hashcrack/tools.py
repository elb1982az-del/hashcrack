"""Tool and wordlist discovery."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Optional

WORDLIST_CANDIDATES = [
    "/usr/share/wordlists/rockyou.txt",
    "/usr/share/dict/wordlist-probable.txt",
    "/usr/share/wordlists/wifite.txt",
    "/usr/share/john/password.lst",
    "/usr/share/dict/words",
]

RULE_CANDIDATES = [
    "/usr/share/hashcat/rules/best66.rule",
    "/usr/share/hashcat/rules/best64.rule",
    "/usr/share/hashcat/rules/d3ad0ne.rule",
]


class ToolError(RuntimeError):
    pass


def which(name: str) -> Optional[str]:
    return shutil.which(name)


def first_existing(candidates) -> Optional[Path]:
    for candidate in candidates:
        path = Path(candidate).expanduser()
        if path.is_file():
            return path
    return None


def find_wordlist(explicit: Optional[str] = None, required: bool = False) -> Optional[Path]:
    if explicit:
        path = Path(explicit).expanduser()
        if not path.is_file():
            raise ToolError(f"wordlist not found: {path}")
        return path
    found = first_existing(WORDLIST_CANDIDATES)
    if required and found is None:
        raise ToolError(
            "no wordlist found. Install rockyou.txt or pass -w /path/to/wordlist.txt"
        )
    return found


def find_rule(explicit: Optional[str] = None) -> Optional[Path]:
    if explicit:
        path = Path(explicit).expanduser()
        if not path.is_file():
            raise ToolError(f"rule file not found: {path}")
        return path
    return first_existing(RULE_CANDIDATES)


def tool_report() -> list[str]:
    lines = []
    for name in ("hashcat", "hcxpcapngtool", "aircrack-ng", "john"):
        lines.append(f"{name:14} {which(name) or 'not found'}")

    wordlist = find_wordlist()
    lines.append(f"wordlist      {wordlist if wordlist else 'not found'}")
    rule = find_rule()
    lines.append(f"rules         {rule if rule else 'not found'}")
    return lines
