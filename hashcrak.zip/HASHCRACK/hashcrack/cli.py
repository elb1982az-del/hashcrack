"""Command line interface for hashcrack."""

from __future__ import annotations

import argparse
from dataclasses import replace
from pathlib import Path
from typing import Optional

from . import __version__
from . import ui
from .backends import Attack, HashcatBackend, PythonBackend
from .detect import Detection
from .target import load_target, prepare_target
from .tools import ToolError, find_rule, find_wordlist, tool_report


def _add_target_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("target", help="hash string, hash file, or WPA capture")
    parser.add_argument("--type", help="force hash type: md5, sha1, sha256, ntlm, wpa, ...")
    parser.add_argument("--mode", type=int, help="force hashcat mode number")


def _add_crack_args(parser: argparse.ArgumentParser, auto_default: bool) -> None:
    _add_target_args(parser)
    parser.add_argument("-w", "--wordlist", help="wordlist path (auto-detects rockyou)")
    parser.add_argument("-r", "--rule", help="rule file (auto-detects best66/best64)")
    parser.add_argument("-m", "--mask", help="mask attack, e.g. '?l?l?l?d?d?d'")
    parser.add_argument("--auto", action="store_true", default=auto_default,
                        help="wordlist, then rules, then mask")
    parser.add_argument("--backend", choices=("auto", "hashcat", "python"),
                        default="auto", help="cracking backend")
    parser.add_argument("--workdir", help="work directory (default: ~/.hashcrack)")
    parser.add_argument("--session", default="default", help="hashcat session name")
    parser.add_argument("--out", help="save cracked passwords here")
    parser.add_argument("--restore", action="store_true", help="resume a hashcat session")
    parser.add_argument("--quiet", action="store_true", help="less output")
    parser.set_defaults(func=run_crack)


def _workdir(value: Optional[str]) -> Path:
    return Path(value).expanduser() if value else Path.home() / ".hashcrack"


def _build_attacks(args: argparse.Namespace) -> list[Attack]:
    wordlist = find_wordlist(args.wordlist, required=bool(args.wordlist))
    attacks: list[Attack] = []

    if wordlist:
        attacks.append(Attack("wordlist", wordlist=wordlist))
        if args.rule or args.auto:
            rule = find_rule(args.rule)
            if rule:
                attacks.append(Attack("rule", wordlist=wordlist, rule=rule))
            elif args.rule:
                raise ToolError(f"rule file not found: {args.rule}")

    if args.mask:
        attacks.append(Attack("mask", mask=args.mask))

    if not attacks:
        raise ToolError("no attack selected. Add -w WORDLIST or -m MASK.")

    for index, attack in enumerate(attacks, 1):
        attack.label = f"{index}. {attack.describe()}"
    return attacks


def _make_backend(args: argparse.Namespace, workdir: Path):
    requested = args.backend
    if requested == "auto":
        if HashcatBackend(workdir, args.session, args.quiet).available():
            requested = "hashcat"
        else:
            requested = "python"

    if requested == "hashcat":
        backend = HashcatBackend(workdir, args.session, args.quiet)
        if not backend.available():
            raise ToolError(
                "hashcat not found on PATH. Use --backend python for MD5/SHA hashes."
            )
        return backend

    return PythonBackend(workdir, args.session, args.quiet)


def run_identify(args: argparse.Namespace) -> int:
    target = load_target(args.target, args.type)
    detection: Detection = target.detection
    if args.mode:
        detection = replace(detection, mode=args.mode,
                            name=detection.name + f" (forced -m {args.mode})")

    ui.header("identify")
    ui.section("Target", target.source)
    ui.section("Detected", detection.name)
    ui.section("Hashcat mode", str(detection.mode) if detection.mode is not None else "unknown")
    ui.section("Confidence", detection.confidence)
    if detection.note:
        ui.section("Note", detection.note)
    if target.count:
        ui.section("Lines", str(target.count))
    return 0


def run_crack(args: argparse.Namespace) -> int:
    workdir = _workdir(args.workdir)
    workdir.mkdir(parents=True, exist_ok=True)

    target = load_target(args.target, args.type)
    detection: Detection = target.detection
    if args.mode:
        detection = replace(
            detection,
            mode=args.mode,
            name=detection.name + f" (forced -m {args.mode})",
        )
        target.detection = detection

    ui.header("hashcrack")
    ui.section("Target", target.source)
    ui.section("Detected", detection.name)
    ui.section("Mode", f"-m {detection.mode}" if detection.mode is not None else "unknown")
    if detection.note:
        ui.detail(detection.note)
    if target.wpa_file:
        ui.detail("WPA capture: a client reply (M2) is required for a crackable handshake.")

    prepared = prepare_target(target, workdir, args.mode)
    if prepared.total:
        ui.section("Hashes", str(prepared.total))

    attacks = _build_attacks(args)
    backend = _make_backend(args, workdir)
    all_found: list[str] = []

    for index, attack in enumerate(attacks, 1):
        ui.header(f"Attack {index}/{len(attacks)}: {attack.describe()}")
        if backend.name == "hashcat":
            result = backend.run(
                prepared,
                attack,
                resume=bool(args.restore and index == 1),
            )
        else:
            result = backend.run(
                prepared,
                attack,
                detection,
                resume=False,
            )

        if result.command:
            ui.detail("cmd: " + " ".join(result.command))
        if result.ok:
            ui.ok(f"Cracked {len(result.found)}")
            for password in result.found:
                print(f"  {password}")
            all_found.extend(result.found)
            if prepared.total <= 1 or len(all_found) >= prepared.total:
                break
        else:
            ui.warn(result.message or "no result")

    if not all_found:
        ui.warn("No password found.")
        return 1

    output = Path(args.out).expanduser() if args.out else workdir / "cracked.txt"
    output.parent.mkdir(parents=True, exist_ok=True)
    existing = []
    if output.is_file():
        existing = [
            line for line in output.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines() if line.strip()
        ]
    merged = list(dict.fromkeys(existing + all_found))
    output.write_text("\n".join(merged) + "\n", encoding="utf-8")
    ui.ok(f"Saved {len(all_found)} result(s) to {output}")
    return 0


def run_wordlists(_args: argparse.Namespace) -> int:
    ui.header("tools and wordlists")
    for line in tool_report():
        print(f"  {line}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hashcrack",
        description="Fast, simple hash cracking: identify, wordlist, rules, masks, WPA.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    identify = subparsers.add_parser("identify", help="identify hash type")
    _add_target_args(identify)
    identify.set_defaults(func=run_identify)

    crack = subparsers.add_parser("crack", help="crack a hash or capture")
    _add_crack_args(crack, auto_default=False)

    auto = subparsers.add_parser("auto", aliases=("a",),
                                 help="wordlist, then rules, then mask")
    _add_crack_args(auto, auto_default=True)

    wordlists = subparsers.add_parser("wordlists", help="show detected tools/wordlists")
    wordlists.set_defaults(func=run_wordlists)

    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except ToolError as exc:
        ui.error(str(exc))
        return 2
    except KeyboardInterrupt:
        ui.warn("interrupted")
        return 130
