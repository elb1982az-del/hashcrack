"""WPA capture conversion for hashcat."""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Optional, Tuple

from .tools import ToolError, which


def _tail(text: str, lines: int = 4) -> str:
    parts = [line.strip() for line in (text or "").splitlines() if line.strip()]
    summary = " | ".join(parts[-lines:]) if parts else ""
    return summary.replace("Information: ", "").strip(" |")


def convert_capture(path: Path, workdir: Path) -> Tuple[Path, int]:
    """Return a hashcat-ready file and mode for a WPA capture."""
    path = path.expanduser()
    workdir.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()

    if suffix == ".hc22000":
        return path, 22000
    if suffix == ".hccapx":
        return path, 2500

    tool = which("hcxpcapngtool")
    if tool:
        output = workdir / f"{path.stem}.hc22000"
        output.unlink(missing_ok=True)
        try:
            proc = subprocess.run(
                [tool, "-o", str(output), str(path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=180,
            )
        except subprocess.TimeoutExpired:
            raise ToolError("hcxpcapngtool timed out while converting the capture.")

        if output.is_file() and output.stat().st_size > 0:
            return output, 22000
        hint = _tail(proc.stderr) or _tail(proc.stdout)
        raise ToolError(
            "no crackable WPA handshake or PMKID found in the capture. "
            "A client reply (M2) is required. " + hint
        )

    fallback = which("aircrack-ng")
    if fallback:
        base = workdir / path.stem
        output = base.with_suffix(".hccapx")
        output.unlink(missing_ok=True)
        try:
            subprocess.run(
                [fallback, "-J", str(base), str(path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=180,
            )
        except subprocess.TimeoutExpired:
            raise ToolError("aircrack-ng timed out while converting the capture.")
        if output.is_file() and output.stat().st_size > 0:
            return output, 2500
        raise ToolError("no crackable WPA handshake found by aircrack-ng.")

    raise ToolError(
        "WPA conversion needs hcxpcapngtool or aircrack-ng. "
        "Install hcxtools or pass an .hc22000/.hccapx file."
    )
