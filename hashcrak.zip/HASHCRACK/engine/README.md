> ⚠️ AUTHORIZED USE ONLY. Use only on hashes and captures you own or are
> explicitly authorized to test.

# HashCrack Commander engine

Local JSON-lines socket engine for the Android HashCrack Commander app.

- Socket: `127.0.0.1:8767`
- CLI: `/sdcard/Download/hashcrack/hashcrack.py`
- Results: `/sdcard/Download/hashcrack/cracked.txt`

## Commands

| cmd | purpose |
| --- | --- |
| `ping` | liveness |
| `status` | engine/running state |
| `files` | list wordlists, rules, hash lists, captures |
| `save_hashes` | save pasted hashes to `hashes/my_hashes.txt` |
| `import_file` | import a base64 file from the Android file picker |
| `identify` | identify a hash or capture |
| `crack` | start wordlist/rule/mask/auto attack |
| `stop` | stop current attack |
| `results` | replay cracked passwords |
| `clear` | clear saved results |

Events: `hello`, `status`, `files`, `log`, `result`, `cracked`.

## Control

```sh
./start.sh
./stop.sh
./relaunch.sh
```

The app **START ENGINE** button runs `/sdcard/Download/HC_LAUNCH.sh`, which is
a copy of `hc_launch.sh` in this folder.
