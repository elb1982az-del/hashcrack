#!/bin/sh
# Fresh HashCrack start: restart engine and open the app.
sh /opt/HashCrack-Commander/stop.sh >/dev/null 2>&1 || true
sleep 1
sh /opt/HashCrack-Commander/start.sh
P=$(ps -A | awk '/hashcrack.commander|hashcrack.comman|crack.commander/{print $1; exit}')
[ -n "$P" ] && kill -9 "$P" 2>/dev/null || true
sleep 1
LD_LIBRARY_PATH=/system/lib64/bootstrap /system/bin/bootstrap/linker64 \
  /system/bin/cmd activity start --activity-clear-task -n com.hashcrack.commander/.MainActivity >/dev/null 2>&1
echo "engine=$(cat /opt/HashCrack-Commander/engine.pid 2>/dev/null)"
echo "app=$(ps -A | awk '/hashcrack.commander|hashcrack.comman|crack.commander/{print $1; exit}')"
