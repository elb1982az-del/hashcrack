#!/usr/bin/env python3
"""Local engine for the HashCrack Android controller."""

from __future__ import annotations

import base64
import json
import os
import re
import signal
import socket
import subprocess
import sys
import threading
import time
from collections import deque
from pathlib import Path

HOST = "127.0.0.1"
PORT = 8767
ROOT = Path("/sdcard/Download/hashcrack")
CLI = ROOT / "hashcrack.py"
CRACKED = ROOT / "cracked.txt"
WORK = ROOT / "work"

MAX_IMPORT_BYTES = 200 * 1024 * 1024
IMPORT_DIRS = {
    "wordlists": "wordlists",
    "rules": "rules",
    "hashes": "hashes",
    "captures": "",
}
IMPORT_SUFFIXES = {
    "wordlists": {".txt", ".lst", ".dic"},
    "rules": {".rule"},
    "hashes": {".txt", ".lst", ".hash"},
    "captures": {".cap", ".pcap", ".pcapng", ".hc22000", ".hccapx"},
}
DEFAULT_SUFFIX = {
    "wordlists": ".txt",
    "rules": ".rule",
    "hashes": ".txt",
    "captures": ".cap",
}


def safe_name(value: str, default: str = "") -> str:
    """Return a flat, safe file name (no directories, no traversal)."""
    name = os.path.basename(value.strip().replace("\\", "/"))
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._-")
    return name[:80] or default


class Engine:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.clients: set[socket.socket] = set()
        self.proc: subprocess.Popen | None = None
        self.running = False
        self.stopped = False
        self.last_cracked: list[str] = []
        self.logs: deque[str] = deque(maxlen=200)

    # ---------- transport ----------

    def send(self, conn: socket.socket, event: str, data=None, **extra) -> None:
        message = {"event": event}
        if data is not None:
            message["data"] = data
        message.update(extra)
        try:
            conn.sendall((json.dumps(message, separators=(",", ":")) + "\n").encode())
        except Exception:
            pass

    def broadcast(self, event: str, data=None, **extra) -> None:
        with self.lock:
            targets = list(self.clients)
        for conn in targets:
            self.send(conn, event, data, **extra)

    def reply(self, conn: socket.socket, cmd: str, ok: bool, message: str, data=None) -> None:
        self.send(conn, "result", data, cmd=cmd, ok=ok, message=message)

    # ---------- state ----------

    def status_data(self) -> dict:
        return {
            "running": self.running,
            "engine_pid": os.getpid(),
            "cracked": len(self.last_cracked),
            "root": str(ROOT),
            "cli": CLI.is_file(),
        }

    def scan_files(self) -> dict:
        result = {"wordlists": [], "rules": [], "hashes": [], "captures": []}
        if not ROOT.is_dir():
            return result

        def add(folder: str, key: str, suffixes: set[str]) -> None:
            path = ROOT / folder
            if not path.is_dir():
                return
            for item in sorted(path.iterdir()):
                if item.is_file() and item.suffix.lower() in suffixes:
                    result[key].append(str(item))

        add("wordlists", "wordlists", {".txt", ".lst", ".dic"})
        add("rules", "rules", {".rule"})
        add("hashes", "hashes", {".txt", ".lst", ".hash"})
        add("", "captures", {".cap", ".pcap", ".pcapng", ".hc22000", ".hccapx"})
        return result

    def read_cracked(self) -> list[str]:
        if not CRACKED.is_file():
            return []
        try:
            return [
                line.strip()
                for line in CRACKED.read_text(encoding="utf-8", errors="replace").splitlines()
                if line.strip()
            ]
        except OSError:
            return []

    # ---------- commands ----------

    def handle_client(self, conn: socket.socket) -> None:
        with self.lock:
            self.clients.add(conn)
        self.send(conn, "hello", {"message": "HashCrack engine online"})
        self.send(conn, "status", self.status_data())
        self.send(conn, "files", self.scan_files())
        self.send(conn, "cracked", {"passwords": self.read_cracked(), "file": str(CRACKED)})

        buffer = b""
        try:
            while True:
                chunk = conn.recv(65536)
                if not chunk:
                    break
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if not line.strip():
                        continue
                    try:
                        message = json.loads(line)
                    except Exception:
                        continue
                    if isinstance(message, dict):
                        self.dispatch(conn, message)
        except Exception:
            pass
        finally:
            with self.lock:
                self.clients.discard(conn)
            try:
                conn.close()
            except Exception:
                pass

    def dispatch(self, conn: socket.socket, message: dict) -> None:
        cmd = str(message.get("cmd", "")).strip()
        if cmd == "ping":
            self.reply(conn, cmd, True, "pong")
        elif cmd == "status":
            self.send(conn, "status", self.status_data())
            self.reply(conn, cmd, True, "ok")
        elif cmd == "files":
            self.refresh_files()
            self.reply(conn, cmd, True, "files refreshed")
        elif cmd == "results":
            self.send(conn, "cracked", {"passwords": self.read_cracked(), "file": str(CRACKED)})
            self.reply(conn, cmd, True, "results sent")
        elif cmd == "clear":
            try:
                CRACKED.parent.mkdir(parents=True, exist_ok=True)
                CRACKED.write_text("", encoding="utf-8")
                self.last_cracked = []
                self.broadcast("cracked", {"passwords": [], "file": str(CRACKED)})
                self.reply(conn, cmd, True, "results cleared")
            except OSError as exc:
                self.reply(conn, cmd, False, f"clear failed: {exc}")
        elif cmd == "read_file":
            self.read_file(conn, message)
        elif cmd == "save_hashes":
            self.save_hashes(conn, message)
        elif cmd == "import_file":
            self.import_file(conn, message)
        elif cmd == "identify":
            self.identify(conn, message)
        elif cmd == "crack":
            self.start_crack(conn, message)
        elif cmd == "stop":
            self.stop_crack(conn)
        else:
            self.reply(conn, cmd or "unknown", False, "unknown command")

    def refresh_files(self) -> dict:
        files = self.scan_files()
        self.broadcast("files", files)
        return files

    def read_file(self, conn: socket.socket, message: dict) -> None:
        """Send a safe preview of a file so the app can display its hashes."""
        raw = str(message.get("path", "")).strip()
        if not raw:
            self.reply(conn, "read_file", False, "path required")
            return
        try:
            path = Path(raw).resolve()
            root = ROOT.resolve()
            if path != root and root not in path.parents:
                self.reply(conn, "read_file", False, "path is outside the app folder")
                return
            if not path.is_file():
                self.reply(conn, "read_file", False, "file not found")
                return
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            self.reply(conn, "read_file", False, f"read failed: {exc}")
            return

        lines = text.splitlines()
        preview = "\n".join(lines[:200])
        if len(lines) > 200:
            preview += f"\n... ({len(lines) - 200} more lines)"
        if len(preview) > 20000:
            preview = preview[:20000] + "\n... (truncated)"
        self.send(
            conn, "file_content",
            {"path": str(path), "name": path.name, "text": preview, "lines": len(lines)},
        )
        self.reply(conn, "read_file", True, f"opened {path.name}")

    def save_hashes(self, conn: socket.socket, message: dict) -> None:
        """Store pasted hashes in the hashes folder so the app can pick them."""
        text = str(message.get("hashes", ""))
        name = safe_name(str(message.get("name", "")), "my_hashes.txt")
        lines = [line.strip() for line in text.splitlines()]
        lines = [line for line in lines if line and not line.startswith("#")]
        if not lines:
            self.reply(conn, "save_hashes", False, "paste at least one hash first")
            return

        if Path(name).suffix.lower() not in IMPORT_SUFFIXES["hashes"]:
            name += ".txt"
        path = ROOT / "hashes" / name
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            if bool(message.get("append")) and path.is_file():
                old = path.read_text(encoding="utf-8", errors="replace").rstrip()
                content = (old + "\n" if old else "") + "\n".join(lines) + "\n"
            else:
                content = "\n".join(lines) + "\n"
            path.write_text(content, encoding="utf-8")
        except OSError as exc:
            self.reply(conn, "save_hashes", False, f"save failed: {exc}")
            return

        self.refresh_files()
        self.reply(
            conn, "save_hashes", True,
            f"saved {len(lines)} hash(es) to {name}",
            {"path": str(path), "count": len(lines)},
        )

    def import_file(self, conn: socket.socket, message: dict) -> None:
        """Import a base64-encoded file from the Android SAF file picker."""
        name = safe_name(str(message.get("name", "")), "imported.txt")
        kind = str(message.get("kind", "hashes")).strip().lower()
        if kind not in IMPORT_DIRS:
            self.reply(conn, "import_file", False, "unknown file type")
            return

        if Path(name).suffix.lower() not in IMPORT_SUFFIXES[kind]:
            name += DEFAULT_SUFFIX[kind]
        folder = IMPORT_DIRS[kind]
        path = (ROOT / folder / name) if folder else (ROOT / name)

        try:
            raw = base64.b64decode(str(message.get("data", "")), validate=True)
        except Exception:
            self.reply(conn, "import_file", False, "file data is not valid base64")
            return
        if not raw:
            self.reply(conn, "import_file", False, "file is empty")
            return
        if len(raw) > MAX_IMPORT_BYTES:
            limit = MAX_IMPORT_BYTES // (1024 * 1024)
            self.reply(conn, "import_file", False, f"file too large (limit {limit} MB)")
            return

        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        except OSError as exc:
            self.reply(conn, "import_file", False, f"import failed: {exc}")
            return

        self.refresh_files()
        self.reply(
            conn, "import_file", True,
            f"imported {name} ({len(raw)} bytes)",
            {"path": str(path), "bytes": len(raw), "kind": kind},
        )

    def identify(self, conn: socket.socket, message: dict) -> None:
        target = str(message.get("target", "")).strip()
        if not target:
            self.reply(conn, "identify", False, "target required")
            return
        if not CLI.is_file():
            self.reply(conn, "identify", False, f"CLI missing: {CLI}")
            return
        cmd = ["python3", str(CLI), "identify", target]
        try:
            proc = subprocess.run(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, timeout=30,
            )
            text = (proc.stdout or "").strip()
            self.reply(conn, "identify", proc.returncode == 0,
                       text[-2000:] or "identify returned no output")
        except Exception as exc:
            self.reply(conn, "identify", False, f"identify failed: {exc}")

    def start_crack(self, conn: socket.socket, message: dict) -> None:
        with self.lock:
            if self.running:
                self.reply(conn, "crack", False, "crack already running")
                return

        target = str(message.get("target", "")).strip()
        if not target:
            self.reply(conn, "crack", False, "choose a hash, hash list, or capture")
            return
        if not CLI.is_file():
            self.reply(conn, "crack", False, f"CLI missing: {CLI}")
            return

        subcommand = "auto" if bool(message.get("auto")) else "crack"
        cmd = ["python3", str(CLI), subcommand, target]

        wordlist = str(message.get("wordlist", "")).strip()
        rule = str(message.get("rule", "")).strip()
        mask = str(message.get("mask", "")).strip()
        hash_type = str(message.get("type", "")).strip()
        mode = str(message.get("mode", "")).strip()

        if wordlist:
            cmd += ["-w", wordlist]
        if rule:
            cmd += ["-r", rule]
        if mask:
            cmd += ["-m", mask]
        if hash_type:
            cmd += ["--type", hash_type]
        if mode:
            cmd += ["--mode", mode]

        WORK.mkdir(parents=True, exist_ok=True)
        CRACKED.parent.mkdir(parents=True, exist_ok=True)
        cmd += ["--workdir", str(WORK), "--out", str(CRACKED)]

        self.stopped = False
        try:
            proc = subprocess.Popen(
                cmd,
                cwd=str(ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
            )
        except Exception as exc:
            self.reply(conn, "crack", False, f"start failed: {exc}")
            return

        with self.lock:
            self.proc = proc
            self.running = True
        self.broadcast("status", self.status_data())
        self.broadcast("log", {"line": "START " + " ".join(cmd)})
        self.reply(conn, "crack", True, "crack started")
        threading.Thread(target=self._pump, args=(proc,), daemon=True).start()

    def stop_crack(self, conn: socket.socket) -> None:
        with self.lock:
            proc = self.proc
        if proc is None or proc.poll() is not None:
            self.reply(conn, "stop", False, "nothing running")
            return
        self.stopped = True
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            try:
                proc.terminate()
            except Exception:
                pass
        threading.Thread(target=self._force_kill, args=(proc,), daemon=True).start()
        self.reply(conn, "stop", True, "stop requested")

    def _force_kill(self, proc: subprocess.Popen) -> None:
        time.sleep(2)
        if proc.poll() is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except Exception:
                pass

    def _pump(self, proc: subprocess.Popen) -> None:
        assert proc.stdout is not None
        try:
            for line in proc.stdout:
                text = line.rstrip("\r\n")
                if text.strip():
                    self.broadcast("log", {"line": text[-240:]})
        except Exception:
            pass

        proc.wait()
        cracked = self.read_cracked()
        with self.lock:
            self.running = False
            self.proc = None
            self.last_cracked = cracked

        self.broadcast("cracked", {"passwords": cracked, "file": str(CRACKED)})
        if self.stopped:
            message = "stopped"
        elif cracked:
            message = f"cracked {len(cracked)}"
        else:
            message = "no password found"
        self.broadcast("result", None, cmd="crack", ok=bool(cracked), message=message)
        self.broadcast("status", self.status_data())

    # ---------- server ----------

    def serve(self) -> None:
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(20)
        print(f"hashcrack engine listening on {HOST}:{PORT}", flush=True)
        while True:
            conn, _addr = server.accept()
            threading.Thread(target=self.handle_client, args=(conn,), daemon=True).start()


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    WORK.mkdir(parents=True, exist_ok=True)
    Engine().serve()


if __name__ == "__main__":
    main()
