#!/bin/sh
# Fresh HashCrack start: stop engine, clear log, start engine, open app.
cd /opt/HashCrack-Commander || exit 1
./stop.sh >/dev/null 2>&1 || true
sleep 1
: > engine.log
./start.sh
P=$(ps -A | awk '/hashcrack.commander|hashcrack.comman|crack.commander/{print $1; exit}')
[ -n "$P" ] && kill -9 "$P" 2>/dev/null || true
sleep 1
LD_LIBRARY_PATH=/system/lib64/bootstrap /system/bin/bootstrap/linker64 \
  /system/bin/cmd activity start --activity-clear-task -n com.hashcrack.commander/.MainActivity >/dev/null 2>&1
sleep 3
echo "engine=$(cat engine.pid 2>/dev/null)"
echo "app=$(ps -A | awk '/hashcrack.commander|hashcrack.comman|crack.commander/{print $1; exit}')"
echo "engine.log=$(wc -c < engine.log) bytes"
