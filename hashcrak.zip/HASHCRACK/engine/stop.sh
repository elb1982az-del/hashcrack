#!/bin/sh
cd /opt/HashCrack-Commander || exit 1
if [ -f engine.pid ]; then
  PID=$(cat engine.pid 2>/dev/null || true)
  if [ -n "$PID" ]; then
    kill "$PID" 2>/dev/null || true
    sleep 1
    kill -9 "$PID" 2>/dev/null || true
  fi
  rm -f engine.pid
fi
pkill -f '/sdcard/Download/hashcrack/hashcrack.py' 2>/dev/null || true
echo stopped
